qTip2 Bower Package
=====

Clone into an existing `qtip2` repo clone, and run the ./bin/build script to generate the files. Then push to the repo.
